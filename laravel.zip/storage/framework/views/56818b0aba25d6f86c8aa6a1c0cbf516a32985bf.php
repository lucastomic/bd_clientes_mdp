

<?php $__env->startSection('content'); ?>
    <button type="button" class="customedBtn" onclick="history.back();">Atrás</button>
    <h1>Bitácora de <?php echo e($cliente->nombre); ?></h1>

    <table class="table">
        <tr>
            <th>Fecha</th>
            <th>Comentario</th>
            <th>Vendedor</th>
        </tr>
        <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($comentario->fecha); ?></td>
                <td><?php echo e($comentario->comentario); ?></td>
                <td><?php echo e($comentario->vendedor); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="centerFlex">
        <button class="customedBtn"><a href='<?php echo e(url("/nuevo_comentario/$cliente->id")); ?>'>Nuevo comentario</a></button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/bitacora.blade.php ENDPATH**/ ?>
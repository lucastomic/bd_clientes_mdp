

<?php $__env->startSection('content'); ?>
    <h1>¿Está seguro de borrar el registro de <?php echo e($cliente->nombre); ?>?</h1>
    <div class="deleteOptions">
        <form action="<?php echo e(route('cliente.destroy', $id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button class="customedBtn deleteBtn deleteBtnYes"><input type="submit" value="Sí"></button>
        </form>
        <button class="customedBtn deleteBtn"><a href="<?php echo e(url('/home')); ?>">No</a></button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/deleteData.blade.php ENDPATH**/ ?>
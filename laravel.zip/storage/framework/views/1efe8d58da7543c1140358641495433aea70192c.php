

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('/home')); ?>" method="post" class="centerFlex">
        <?php echo csrf_field(); ?>
        <label for="name">Nombre</label>
        <input type="text" name="name">

        <label for="type">Tipo</label>
        <input type="text" name="type">

        <label for="product">Producto</label>
        <input type="text" name="product">

        <label for="ubication">Ubicación</label>
        <input type="text" name="ubication">

        <label for="active">Actividad</label>
        <select name="active">
            <option value="todos">Todos</option>
            <option value="on">Activos</option>
            <option value="off">Inactivos</option>
        </select>

        <input type="submit" class="submitBtn" value="Buscar">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/filter.blade.php ENDPATH**/ ?>
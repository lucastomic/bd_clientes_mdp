

<?php $__env->startSection('content'); ?>
<button type="button" class="customedBtn" onclick="history.back();">Atrás</button>
    <h1><?php echo e($cliente->nombre); ?></h1>

    <table>
        <tr>
            <th class="thHead" data-name="nombre"><button class="thBtn">Nombre</button></th>
            <td class="nombre"><?php echo e($cliente->nombre); ?></td>
        </tr>
        <tr>
            <th class="thHead" data-name="tipo"><button class="thBtn">Tipo</button></th>
            <td class="tipo"><?php echo e($cliente->tipo); ?></td>
        </tr>
        <tr>
            <th class="thHead" data-name="producto"><button class="thBtn">Producto</button></th>
            <td class="producto"><?php echo e($cliente->producto); ?></td>
        </tr>
        <tr>
            <th class="thHead" data-name="ubicacion"><button class="thBtn">Ubicacion</button></th>
            <td class="ubicacion"><a href="https://maps.google.com/?ll=<?php echo e($cliente->latitud); ?>,<?php echo e($cliente->longitud); ?>&z=18" target="_blank"><?php echo e($cliente->ubicacion); ?></a></td>
        </tr>
        <tr>
            <th class="thHead" data-name="telefono"><button class="thBtn">Teléofno</button></th>
            <td class="telefono"><a href="tel:<?php echo e($cliente->telefono); ?>"><?php echo e($cliente->telefono); ?></a></td>
        </tr>
        <tr>
            <th class="thHead" data-name="mail"><button class="thBtn">Mail</button></th>
            <td class="mail"><?php echo e($cliente->mail); ?></td>
        </tr>
        <tr>
            <th class="thHead" data-name="cif"><button class="thBtn">CIF</button></th>
            <td class="cif"><?php echo e($cliente->cif); ?></td>
        </tr>
        <tr>
            <th class="thHead" data-name="observaciones"><button class="thBtn">Observaciones</button></th>
            <td class="observaciones"><?php echo e($cliente->observaciones); ?></td>
        </tr>
        <tr>
            <th>Activo</th>
            <td class="activo">
                <?php if($cliente->activo): ?>
                    <img width='15vh' class="active" src="<?php echo e(asset('images/green_circle.png')); ?>" alt=''>
                <?php else: ?>
                    <img width='15vh' class="non-active" src="<?php echo e(asset('images/red_circle.png')); ?>" alt=''>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th>Bitácora</th>
            <td><button><a href='<?php echo e(url("/bitacora/$cliente->id")); ?>'>Bitácora</a></button></td>
        </tr>
        <tr>
            <td><button><a href='<?php echo e(url("/updateData/$cliente->id")); ?>'>Editar datos</a></button></td>
            <td><button><a href='<?php echo e(url("/deleteData/$cliente->id")); ?>'>Borrar cliente</a></button></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/client.blade.php ENDPATH**/ ?>
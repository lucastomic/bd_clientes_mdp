

<?php $__env->startSection('content'); ?>
    <button type="button" class="customedBtn" onclick="history.back();">Atrás</button>
    <h1>Editar datos</h1>
    <form action='<?php echo e(route("cliente.update", $id)); ?>' method="post" id="form" class="centerFlex">
        <?php echo csrf_field(); ?>    
        <?php echo method_field('PUT'); ?>
        <label for="name">Nombre</label>
        <input type="text" name="name" value="<?php echo e($cliente->nombre); ?>">
        <label for="type">Tipo</label>
        <select name="type">
            <option <?php if($cliente->tipo === "Mayorista") echo "selected='selected'"?> value="Mayorista">Mayorista</option>
            <option <?php if($cliente->tipo === "Pescaderia") echo "selected='selected'"?> value="Pescaderia">Pescadería</option>
            <option <?php if($cliente->tipo === "Distribuidor") echo "selected='selected'"?> value="Distribuidor">Distribuidor</option>
        </select>
        <label for="ubication">Ubicacion</label>
        <input type="text" name="ubication" value="<?php echo e($cliente->ubicacion); ?>" id="ubication">
        <label for="telephone">Teléfono</label>
        <input type="text" name="telephone" value="<?php echo e($cliente->telefono); ?>">
        <label for="mail">Mail</label>
        <input type="text" name="mail" value="<?php echo e($cliente->mail); ?>">
        <label for="product">Producto</label>
        <input type="text" name="product" value="<?php echo e($cliente->producto); ?>">
        <label for="active">Activo</label>
        <input type="checkBox" name="active" 
            <?php if($cliente->activo): ?>
            checked
            <?php endif; ?>
>
        <label for="cif">CIF</label>
        <input type="text" name="cif" value="<?php echo e($cliente->cif); ?>">
        <label for="observations">Observaciones</label>
        <input type="text" name="observations" value="<?php echo e($cliente->observaciones); ?>">
        <input type="hidden" name="latitude" id="latitude" value="<?php echo e($cliente->latitud); ?>">
        <input type="hidden" name="longitude" id="longitude" value="<?php echo e($cliente->longitud); ?>">
        <input type="submit" id="submitBtn" value="Actualizar" class="customedBtn submitBtn">
    </form>

    <script>
        const getCoords = (dir) =>{
            const direccion = dir.replace(/ /g,"+"),
            $form = document.getElementById("form")
            fetch('https://maps.googleapis.com/maps/api/geocode/json?address='+direccion+'&key=AIzaSyCz8IS8ryD6Z5kn8Rvq6DwObryxnZcBDpo')
            .then(response => response.json())
            .then(data =>{
                let latitude = data.results[0].geometry.location.lat,
                longitude = data.results[0].geometry.location.lng

                document.getElementById("latitude").value = latitude
                document.getElementById("longitude").value = longitude 
            })
            .then(()=>$form.submit())
        }   

        document.getElementById("submitBtn").addEventListener("click", (e)=>{
            if(document.getElementById("ubication").value != ""){
                e.preventDefault();
                getCoords(document.getElementById("ubication").value)
            }
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/updateData.blade.php ENDPATH**/ ?>
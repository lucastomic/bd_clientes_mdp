

<?php $__env->startSection('content'); ?>
    <button class="customedBtn"><a href="<?php echo e(url('/')); ?>"> Volver Atrás</a></button>
    <?php if(Session::has('flashData')): ?>
        <span class="flashData"><?php echo e(session('flashData')); ?></span>
    <?php endif; ?>
    <h1>Crear nuevo usuario</h1>

    <form action="<?php echo e(url('/createUser')); ?>" method="post" class="centerFlex">
        <?php echo csrf_field(); ?>
        <label for="username">Nombre</label>
        <input type="text" name="username">
        <label for="password">Contraseña</label>
        <input type="password" name="password">
        <input type="submit" value="Enviar">
    </form>
    <script>
        const $flashData = document.querySelector(".flashData");
        if($flashData != null){
            setTimeout(() => {
                $flashData.innerText = "";
            }, 5000);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/createNewUser.blade.php ENDPATH**/ ?>
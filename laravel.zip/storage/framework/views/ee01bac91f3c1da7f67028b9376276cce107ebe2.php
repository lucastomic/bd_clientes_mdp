<?php $__env->startSection('content'); ?>
    <?php if(Session::has('flashData')): ?>
        <span class="flashData"><?php echo e(session('flashData')); ?></span>
    <?php endif; ?>

    <form action="<?php echo e(url('/join')); ?>" method="post" class="centerFlex">
    <?php echo csrf_field(); ?>
        <label for="user">Usuario</label>
        <input name="user" type="text">
        <label for="password">Password</label>
        <input name="password" type="password">
        <input type="submit" value="Entrar" class="customedBtn submitBtn">
        <button class="customedBtn"><a href="<?php echo e(url('crear_usuario')); ?>">Crear usuario</a></button>
    </form>
    <script>
        const $flashData = document.querySelector(".flashData");
        if($flashData != null){
            setTimeout(() => {
                $flashData.innerText = "";
            }, 3000);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\baseClientes\resources\views/join.blade.php ENDPATH**/ ?>